﻿namespace PS.Template.Application.Services
{
    internal interface IGenericsRepository
    {
    }
}