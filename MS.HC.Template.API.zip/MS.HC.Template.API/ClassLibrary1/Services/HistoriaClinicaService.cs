﻿
using HCTemplateDomain.DTOs;
using HCTemplateDomain.Entities;
using MS.HC.Domain.Commands;
using System;

namespace HC.Application.Services
{
    public interface IHistoriaClinicaService
    {
        HistoriasClinicas CreateHistoriaClinica(HistoriasClinicasDto HistoriaClinica);
    }
    public class HistoriaClinicaService : IHistoriaClinicaService
    {
        private readonly IGenericsRepository  _repository;
        public HistoriaClinicaService(IGenericsRepository repository)
        {
            _repository = repository;
        }

        public HistoriasClinicas CreateHistoriasClinicas(HistoriasClinicasDto Historia)
        {
            var entity = new HistoriasClinicas
            {
                //HistoriaClinica_id = Guid.NewGuid(),
                //Paciente_id = Guid.Parse(Pacientes.PacienteId),
                //Medico_id = Guid.Parse(Medicos.MedicoId),
                //FechaConsulta = Parse(Turnos.AgendaId),
                //DetalleDeConsulta = string.Empty,
            };
            _repository.Add<HistoriasClinicas>(entity);

            return entity;
        }

        public HistoriasClinicasDto CreateHistoriaClinica(HistoriasClinicasDto HistoriaClinica)
        {
            throw new NotImplementedException();
        }

        HistoriasClinicas IHistoriaClinicaService.CreateHistoriaClinica(HistoriasClinicasDto HistoriaClinica)
        {
            throw new NotImplementedException();
        }
    }
}
