﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MS.HC.Domain.Commands
{
    public interface IGenericsRepository
    {
        void Add<T>(T entity) where T : class;
    }
}
