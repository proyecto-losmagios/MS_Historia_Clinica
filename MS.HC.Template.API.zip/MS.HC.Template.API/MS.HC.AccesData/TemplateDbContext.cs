﻿using HC.Application.Services;
using HCTemplateDomain.DTOs;
using HCTemplateDomain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Data.Entity;

namespace HCTemplateAccesData
{
    public class HCTemplateContext : Microsoft.EntityFrameworkCore.DbContext
    {
        public HCTemplateContext(DbContextOptions<HCTemplateContext> options)
            : base(options) { }
  

        public Microsoft.EntityFrameworkCore.DbSet<HistoriasClinicasDto> historiasClinicas { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) { optionsBuilder.UseSqlServer("Data Source=blog.db"); }

        public HistoriasClinicas CreateHistoriasClinicas(HistoriasClinicasDto historias)
        {
            throw new NotImplementedException();
        }

        public static implicit operator HCTemplateContext(HistoriaClinicaService v)
        {
            throw new NotImplementedException();
        }
    }


}
}
