﻿using HC.Application.Services;
using HCTemplateAccesData;
using HCTemplateDomain.DTOs;
using HCTemplateDomain.Entities;
using Microsoft.AspNetCore.Mvc;


namespace MS.HC.Template.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HCController : ControllerBase
    {
        private readonly HCTemplateContext _context;
        public HCController(HistoriaClinicaService context)
        {
            _context = context;
        }

        [HttpPost]
        public HistoriasClinicas Post(HistoriasClinicasDto historias)
        {
            return _context.CreateHistoriasClinicas(historias);
        }
    }
}